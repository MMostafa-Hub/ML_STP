
## TODO: Add the Needed imports Here ##



def predict(sentences):
    
    '''
    Arguments
    This Function takes LIST of sentences as an argument (List of Strings) -> ["sent1", "sent2", "sent3"] 

    Returns 
    List of Numeric Prediction Aka ClassNumber as Given Example [1, 3, 5, 12, ...etc] 
    '''
    
    predictions = []
    


    ## ToDo: Write Your Code HERE! ##

    return predictions

### DON'T WORRY ABOUT IT :) ###
## Machathon Technical Team Send their regards